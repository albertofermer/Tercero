package practica7;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author usuario
 */
public class EstudianteTeoria extends Thread{
    
    Revision r;
    int id;
    
    public EstudianteTeoria(Revision r, int id){
        this.r = r;
        this.id = id;
    }
    
    @Override
    public void run(){
        r.entraTeoria();
        System.out.println("Estudiante " + id + " revisa teoría.");
        r.saleTeoria();
    }
}
