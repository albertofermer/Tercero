/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica7;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;

/**
 *
 * @author usuario
 */
public class CanvasP7 extends Canvas{
    
    public CanvasP7(){
        setSize(500, 500);
        setBackground(Color.red);
    }
    
    public void repaint(Graphics g){
        paint(g);
    }
    
    @Override
    public void paint(Graphics g){
        
        Graphics of;
    }
}
