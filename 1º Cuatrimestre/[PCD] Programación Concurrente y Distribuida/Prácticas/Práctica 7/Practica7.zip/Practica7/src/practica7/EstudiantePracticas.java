package practica7;

/**
 *
 * @author usuario
 */
public class EstudiantePracticas implements Runnable{

    Revision r;
    int id;
    
    public EstudiantePracticas(Revision r, int id){
        this.r = r;
        this.id = id;
    }
    
    @Override
    public void run() {
        r.entraPracticas();
        System.out.println("Estudiante " + id + " revisa prácticas.");
        r.salePracticas();
    }
    
}
