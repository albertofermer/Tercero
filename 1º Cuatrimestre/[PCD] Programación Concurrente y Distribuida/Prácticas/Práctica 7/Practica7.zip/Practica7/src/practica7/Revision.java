package practica7;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 *
 * @author usuario
 */
public class Revision {

    int numPortatilLibre;
    boolean noPortatilLibre;
    Lock lockTeoria;
    //Lock lockPracticas;
    Condition teoria;
    Condition practicas;
    char quien;
    
    
    public Revision() {
        numPortatilLibre = 2;
        noPortatilLibre = true;
        lockTeoria = new ReentrantLock();
        //lockPracticas = new ReentrantLock();
        teoria = lockTeoria.newCondition();
        practicas = lockTeoria.newCondition();
        //practicas = lockPracticas.newCondition();
    }

    public void entraTeoria() throws InterruptedException {
        lockTeoria.lock();
        
        try{
            if (!noPortatilLibre && (numPortatilLibre == 0)) {
                teoria.await(); //Si estan todos los profesores ocupados espero
            }
            
            if (noPortatilLibre) {
                //atiende el que no tiene portatil
                noPortatilLibre = false;
                quien = 'n'; 
            }
            else{
                //atiende uno de los que tiene portatil
                numPortatilLibre--;
                quien = 'p';
            }
            
        }finally{lockTeoria.unlock();}
    }

    public void entraPracticas() {
        
    }

    public void saleTeoria(char quien) {
        
        if (quien == 'n') { //Si le ha atendido el que no tiene portatil
            noPortatilLibre = true;
            // y aviso de que he salido 
            teoria.signal();
        }
        else{
            numPortatilLibre++;
            //aviso a la cola de practicas de que he salido
            practicas.signal();
        }
    }

    public void salePracticas() {
        
        //Siempre va a salir de uno con portatil
        
    }

}
