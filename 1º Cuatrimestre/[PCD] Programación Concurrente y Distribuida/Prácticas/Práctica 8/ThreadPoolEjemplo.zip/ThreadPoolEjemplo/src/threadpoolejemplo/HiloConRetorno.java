package threadpoolejemplo;

import static java.lang.Thread.sleep;
import java.util.concurrent.Callable;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author usuario
 */
public class HiloConRetorno implements Callable<Integer> {

    private int id;

    public HiloConRetorno(int id) {
        this.id = id;
        System.out.println("Creado runnable " + id);
    }

    @Override
    public Integer call() { //Devuelve un valor entero
        long hid = Thread.currentThread().getId();
        for (int i = 0; i < 5; i++) {
            try {
                System.out.println("Soy la tarea " + id + " estoy corriendo en el hilo " + hid);
                sleep(1000);
            } catch (InterruptedException ex) {
                System.out.println(ex.getMessage());
            }
        }

        return this.id * 1000;
    }

}
