package threadpoolejemplo;

import static java.lang.Thread.sleep;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author usuario
 */
public class HiloSinRetorno implements Runnable{

    private int id;
    
    public HiloSinRetorno(int id)
    {
        this.id = id;
        System.out.println("Creado runnable " + id);
    }
    
    @Override
    public void run() {
        long hid = Thread.currentThread().getId();
        for (int i = 0; i < 5; i++) {
            try {
                System.out.println("Soy la tarea " + id + " estoy corriendo en el hilo " + hid);
                sleep(1000);
            } catch (InterruptedException ex) { System.out.println(ex.getMessage());
            }
        }
    }
    
}
