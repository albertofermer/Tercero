package threadpoolejemplo;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 *
 * @author usuario
 */
public class ThreadPoolEjemplo {

    /**
     * @param args the command line arguments
     * @throws java.util.concurrent.ExecutionException
     * @throws java.lang.InterruptedException
     */
    public static void main(String[] args) throws ExecutionException, InterruptedException {

        ExecutorService thp = Executors.newFixedThreadPool(3); //ThreadPool 

//        for (int i = 0; i < 5; i++) {
//            HiloSinRetorno r = new HiloSinRetorno(i);
//            thp.submit(r); //Envía el runnable
//        }
        ArrayList<Future <Integer> > f = new ArrayList();
        for (int i = 0; i < 5; i++) {
            HiloConRetorno rr = new HiloConRetorno(i + 5);
            f.add(thp.submit(rr));

        }

        for (int i = 0; i<f.size(); i++) {
            System.out.println("El hilo devuelve " + f.get(i).get());
        }

        thp.shutdown();

    }

}
