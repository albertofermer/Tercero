/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package claseejemplo1;

/**
 * Clase de Ejemplo linea1
 *
 * @version 0.1 14/10/21
 * @author usuario
 */
public class saludos implements IClaseEjemplo {

    private int manera;

    public saludos(int tipo) {

        this.manera = tipo;
    }

    /**
     * Clase de Ejemplo linea1 linea2
     *
     * @author usuario
     *
     *
     * @param mensaje
     * @throws Exception
     */
    @Override
    public void saluda(String mensaje) throws Exception {
        switch (manera) {
            case 0:
                System.out.println("Tipo0: " + mensaje);
                break;
            case 1:
                System.out.println("Tipo1");
                break;
            default:
                throw new Exception("Error de tipo");
        }
    }

    /**
     *
     * @param args
     */
    public static void main(String[] args) {

        saludos s1 = new saludos(1);
        saludos s2 = new saludos(0);
        saludos s3 = new saludos(2);

        try {

            s1.saluda("----");
            s2.saluda("----");
            s3.saluda("----");

        } catch (Exception ex) {
            System.out.println("Fallo " + ex.getMessage() + " ");

        }

    }
}
