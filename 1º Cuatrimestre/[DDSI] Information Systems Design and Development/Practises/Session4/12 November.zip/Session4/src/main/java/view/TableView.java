package view;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author usuario
 */
public class TableView {
    DefaultTableModel model;
    JTable table;
    
    
    public TableView() {
        model = new DefaultTableModel();
        table = new JTable();
        table.setModel(model);
    }
    
    public DefaultTableModel modelTableMember = new DefaultTableModel(){
        
        @Override
        public boolean isCellEditable(int row, int column){
            return false;
        }
    };
    
}
