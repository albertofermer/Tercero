package model;

/**
 *
 * @author usuario
 */
public class jTableModel {
    
}
