/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import model.ConnectionDB;
import view.LoginView;
import view.MainWindow;
import view.MessageView;

/**
 *
 * @author usuario
 */
public class Controller implements ActionListener {

    private LoginView vLogin;
    private ConnectionDB connection = null;
    private MessageView vMessage = null;
    private boolean connectionOK = false;
    private MainWindow mainwindow = null;
    public Controller() {
        vLogin = new LoginView();
        vMessage = new MessageView();
        
        addListener();

        vLogin.setLocationRelativeTo(null);
        vLogin.setVisible(true);
    }

    private void addListener() {
        vLogin.Connect.addActionListener(this);
        vLogin.Exit.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        switch (e.getActionCommand()) {
            case "Connect":
                connectionOK = connect();
                break;
            case "Exit":
                vLogin.dispose();
            default:
                throw new AssertionError();
        }

    }

    private boolean connect() {

        boolean result = false;
        try {
            String Server = (String) vLogin.Server.getSelectedItem();
            String IP = vLogin.IP.getText();
            String Service = vLogin.DB.getText();
            String User = vLogin.User.getText();
            String Pass = new String(vLogin.Pass.getPassword());

            ConnectionDB connection = new ConnectionDB();
            nuevaVentana(true);
            result = true;
            vMessage.Message("info", "Connection Succesful");
        } catch (SQLException e) {

            System.out.println(e.getMessage());
            vMessage.Message("ERROR: ", e.getMessage());

        } catch (ClassNotFoundException e) {

            vMessage.Message("ERROR: ", "Undeterminated - " + e.getMessage());
        }

        return result;
    }
    
    private void nuevaVentana(boolean result)
    {
        
        if (result) {
            System.out.println("Entra");
            mainwindow.setVisible(true);
        }
    }

}
