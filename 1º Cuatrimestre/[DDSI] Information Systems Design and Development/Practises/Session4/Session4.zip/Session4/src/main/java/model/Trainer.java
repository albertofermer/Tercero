package model;

/**
 *
 * @author usuario
 */
public class Trainer {
    private String t_name;
    private String t_surname1;
    private String t_surname2;
    private String t_idnumber;
    private String t_phonenumber;
    private String t_email;
    private String t_date;
    private String t_nick;
}
