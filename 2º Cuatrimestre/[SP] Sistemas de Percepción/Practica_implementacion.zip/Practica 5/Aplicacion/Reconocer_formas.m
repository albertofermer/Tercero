
addpath("Funciones\");
addpath("../MaterialFacilitado/MaterialFacilitado/Funciones/");
addpath("../TerceraPruebaEvaluacionSP_Junio21_22/");

Nombre = "Test_01";
funcion_reconoce_formas(Nombre);

pause, close all, clear;

Nombre = "Test_02";
funcion_reconoce_formas(Nombre);

