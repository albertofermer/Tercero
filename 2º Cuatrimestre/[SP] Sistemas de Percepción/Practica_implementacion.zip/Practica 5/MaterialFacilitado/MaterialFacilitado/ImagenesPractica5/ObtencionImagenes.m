%Obtencion de las imagenes de entrenamiento de los distintas figuras.
addpath("MaterialFacilitado\MaterialFacilitado\ImagenesPractica5\Entrenamiento\");

Itri01 = imread("Triangulo01.jpg");
Itri02 = imread("Triangulo02.jpg");
Icua01 = imread("Cuadrado01.jpg");
Icua02 = imread("Cuadrado02.jpg");
Icir01 = imread("Circulo01.jpg");
Icir02 = imread("Circulo02.jpg");


