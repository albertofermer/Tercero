#pragma once

#include <GL/glew.h>
#include "CGPiece.h"

class CGSlotCar_0 : public CGPiece {
public:
	CGSlotCar_0(CGMaterial* mtl);
};

class CGSlotCar_1 : public CGPiece {
public:
	CGSlotCar_1(CGMaterial* mtl);
};


