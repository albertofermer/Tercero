#pragma once
#include <GL/glew.h>
#include "CGFigure.h"

class CGArco : public CGFigure
{
public:
	CGArco(GLfloat r0, GLfloat r1, GLfloat h);
};

