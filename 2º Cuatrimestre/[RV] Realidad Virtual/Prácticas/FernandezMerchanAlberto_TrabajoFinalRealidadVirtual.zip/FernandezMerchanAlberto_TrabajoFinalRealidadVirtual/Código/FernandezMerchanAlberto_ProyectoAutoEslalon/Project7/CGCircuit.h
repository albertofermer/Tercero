#pragma once
#include "CGArco.h"
class CGCircuit
{
public:
	CGCircuit(int NUM_ARCOS, CGFigure* arcos[], int radio);
};

