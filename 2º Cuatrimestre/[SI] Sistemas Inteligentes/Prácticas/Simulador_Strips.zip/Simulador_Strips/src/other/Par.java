package other;

/**
 * @author Luis Javier
 * Clase para crear pares de objetos
 */
public class Par {
    public Object prop1;
    public Object prop2;
 
    public Par(Object prop1, Object prop2) {
        this.prop1 = prop1;
        this.prop2 = prop2;
    }
}
