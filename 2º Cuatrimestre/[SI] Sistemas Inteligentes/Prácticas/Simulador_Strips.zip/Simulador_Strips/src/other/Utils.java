package other;

import java.util.ArrayList;
import java.util.List;


/**
 * @author Luis Javier
 * Clase de funciones �tiles
 */
public class Utils {

	/**
	 * Unifica las cadenas de un array en un �nico String
	 * 
	 * @param arr Array con las cadenas de texto
	 * @return Listado unificado de las cadenas de texto
	 */
	public static String getStrFromArr(String[] arr) {
		String str = "";
		for (int i = 0; i < arr.length; i++) {
			str += arr[i];
			if (i + 1 < arr.length) {
				str += ",";
			}
		}
		return str;
	}

	/**
	 * Funci�n para alternar cadenas
	 * 
	 * @param str Array de cadenas
	 * @param i   Posicion 1
	 * @param j   Posicion 2
	 */
	private static void swap(String[] str, int i, int j) {
		String temp = str[i];
		str[i] = str[j];
		str[j] = temp;
	}

	/**
	 * Funci�n recursiva para generar todas las permutaciones posibles
	 * 
	 * @param str       Array de cadenas
	 * @param currIndex �ndice actual
	 * @param l         Listado de permutaciones
	 */
	private static void permutaciones(String[] str, int currIndex, List<String[]> l) {
		if (currIndex == str.length - 1) {
			l.add(str.clone());
		}
		for (int i = currIndex; i < str.length; i++) {
			swap(str, currIndex, i);
			permutaciones(str, currIndex + 1, l);
			swap(str, currIndex, i);
		}
	}

	/**
	 * Devuelve un listado de permutaciones en base a un array de cadenas de
	 * car�cteres
	 * 
	 * @param str Array de cadenas
	 * @return Listado de permutaciones
	 */
	public static List<String[]> getPermutaciones(String[] str) {
		List<String[]> l = new ArrayList<String[]>();
		if (str == null || str.length == 0) { // Caso base
			return null;
		}
		permutaciones(str, 0, l);
		return l;
	}
}
