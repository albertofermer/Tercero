package algorithms;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.Stack;

import other.Par;
import other.Utils;

/**
 * @author Luis Javier
 * Clase para el algoritmo STRIPS
 */
public class A_Strips {

	static Estado eActual;

	/**
	 * Realiza una simulaci�n del algoritmo Strips y almacena cada plan factible
	 * @param e_Inicial Estado inicial
	 * @param e_Objetivo Estado meta u objetivo
	 * @param ops Operadores a considerar
	 * @param primeraFactible Define si acaba al encontrar el primer factible
	 * @return Par de {permutacion, plan} soluci�n
	 * @throws CloneNotSupportedException
	 */
	public static List<Par> Simular(Estado e_Inicial, Estado e_Objetivo, Operadores ops, boolean primeraFactible) throws CloneNotSupportedException {
		List<Par> li = new ArrayList<Par>();
		Stack<Object> pila = new Stack<Object>();
		Plan plan = new Plan();
		String[] strs = new String[e_Objetivo.getDef().size()];
		e_Objetivo.getDef().toArray(strs);
		List<String[]> permutaciones = Utils.getPermutaciones(strs);
		for (String[] perm : permutaciones) {
			pila.clear();
			plan = new Plan();
			for (String str : perm) {
				pila.add(str);
			}
			plan = Strips_Recursivo(plan, ops, e_Inicial.clone(), e_Objetivo, pila);
			if (plan != null && esFactible(eActual, e_Objetivo)) {
				li.add(new Par(perm, plan));
				if(primeraFactible) {
					break;
				}
			} else {
				plan = null;
			}
		}

		return li;
	}

	/**
	 * Devuelve si la soluci�n es factible
	 * @param e_Actual Estado actual
	 * @param e_Objetivo Estado objetivo
	 * @return True/false si es factible
	 */
	private static boolean esFactible(Estado e_Actual, Estado e_Objetivo) {
		for (String str : e_Objetivo.getDef()) {
			if (!e_Actual.contains(str)) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Algoritmo STRIPS recursivo utilizado
	 * @param plan Plan que se est� siguiendo hasta ahora
	 * @param ops Conjunto de operadores a considerar
	 * @param e_Actual Estado actual
	 * @param e_Objetivo Estado objetivo
	 * @param pila Pila con los objetos y acciones
	 * @return Devuelve el plan a null si no hay salida o con valor si es correcto
	 * @throws CloneNotSupportedException
	 */
	@SuppressWarnings("unchecked")
	static Plan Strips_Recursivo(Plan plan, Operadores ops, Estado e_Actual, Estado e_Objetivo, Stack<Object> pila)	throws CloneNotSupportedException {
		if (pila.empty()) {
			eActual = e_Actual;
			return plan;
		} else {
			Object cima = pila.peek();
			switch (cima.getClass().getSimpleName()) { // Accion, String
			case "String":
				if (e_Actual.contains((String) cima)) {
					pila.pop();
					return Strips_Recursivo(plan, ops, e_Actual, e_Objetivo, pila);
				} else {
					List<Accion> accionesPosibles = buscarAcciones((String) cima, ops);
					if (!accionesPosibles.isEmpty()) {
						for (Accion acc : accionesPosibles) {
							if (!pila.contains(acc)) {
								Stack<Object> pilaCopy = (Stack<Object>) pila.clone();
								Plan sig = null;
								if (acc.cumplePrecond(e_Actual)) {
									pilaCopy.push(acc);
									sig = Strips_Recursivo(plan, ops, e_Actual.clone(), e_Objetivo, pilaCopy);
								} else {
									Set<String> precond = acc.getPrecond();
									for (String pre : precond) {
										pilaCopy.push(pre);
									}
									sig = Strips_Recursivo(plan, ops, e_Actual.clone(), e_Objetivo, pilaCopy);
								}
								if (sig != null) {
									return sig;
								}
							}
						}
						return null;
					} else {
						return null;
					}
				}
			case "Accion":
				Accion ac = (Accion) pila.pop();
				e_Actual.aplicar(ac);
				Stack<Object> pilaCopy = (Stack<Object>) pila.clone();
				Plan sig = Strips_Recursivo(plan, ops, e_Actual.clone(), e_Objetivo, pilaCopy);
				if (sig != null) {
					plan.addAccion(ac);
					return plan;
				} else {
					return null;
				}
			default:
				return null;
			}
		}
	}

	/**
	 * Devuelve las acciones plausibles con respecto a la cima de la pila
	 * @param cima Cima de la pila
	 * @param ops Operadores disponibles
	 * @return Lista de acciones
	 */
	static List<Accion> buscarAcciones(String cima, Operadores ops) {
		List<Accion> accs = new ArrayList<Accion>();
		for (Accion acc : ops.getAcciones()) {
			if (acc.esPlausible(cima)) {
				accs.add(acc);
			}
		}
		return accs;
	}
}
