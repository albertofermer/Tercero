package algorithms;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @author Luis Javier
 * Clase para definir un plan de acciones. Extiende de Operadores.
 */
public class Plan extends Operadores{
	
	@Override
	public String toString() {
		String str = "Plan [acciones: {";
		List<Accion> invAcciones = new ArrayList<Accion>();
		invAcciones.addAll(acciones);
		Collections.reverse(invAcciones);
		for (int i = 0; i < invAcciones.size(); i++) {
			str += invAcciones.get(i).getNombre();
			if(i+1 < invAcciones.size()) {
				str += ",";
			}
		}
		str += "}]";
		return str;
	}
	
}
