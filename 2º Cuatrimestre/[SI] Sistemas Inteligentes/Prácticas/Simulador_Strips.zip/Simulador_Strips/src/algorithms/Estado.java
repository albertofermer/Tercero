package algorithms;

import java.util.HashSet;
import java.util.Set;

/**
 * @author Luis Javier
 * Clase para definir un estado
 */
public class Estado implements Cloneable {

	String nombre;
	Set<String> def = new HashSet<String>();

	/**
	 * Constructor
	 * @param nombre nombre del estado
	 * @param def String de definici�n del estado
	 */
	public Estado(String nombre, String def) {
		this.nombre = nombre;
		String[] strs = def.trim().replaceAll(" ", "").split(",");
		for (String str : strs)
			this.def.add(str);
	}
	
	/**
	 * Aplica una acci�n al estado actual
	 * @param ac Acci�n a aplicar
	 */
	public void aplicar(Accion ac) {
		for(String sup: ac.getSupresion()) {
			this.def.remove(sup);
		}
		for(String ad: ac.getAdicion()) {
			this.def.add(ad);
		}
	}

	/**
	 * Comprueba si la definici�n del estado contiene la cadena de texto
	 * @param cad Cadena de texto
	 * @return True si la contiene, false si no la contiene
	 */
	public boolean contains(String cad) {
		Set<String> strs = getDef();
		return strs.contains(cad);
	}

	@Override
	public String toString() {
		return "Estado " + nombre + ": {" + def + "}";
	}

	@Override
	protected Estado clone() throws CloneNotSupportedException {
		Estado e = (Estado)super.clone();
		Set<String> copy = new HashSet<String>();
		copy.addAll(def);
		e.def = copy;
		return e;
	}

	/** GETTER Y SETTER **/
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public Set<String> getDef() {
		return def;
	}
	public void setDef(Set<String> def) {
		this.def = def;
	}
	/** **/

}
