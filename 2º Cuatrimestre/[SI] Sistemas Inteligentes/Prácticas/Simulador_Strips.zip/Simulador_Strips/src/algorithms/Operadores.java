package algorithms;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Luis Javier
 * Clase para definir los operadores a considerar
 */
public class Operadores {
	
	List<Accion> acciones = new ArrayList<Accion>();
	
	/**
	 * A�ade una accion a la lista de acciones.
	 * @param acc Acci�n a a�adir
	 */
	public void addAccion(Accion acc) {
		this.acciones.add(acc);
	}
	
	/**
	 * Elimina una acci�n a la lista de acciones.
	 * @param acc Acci�n a a�adir
	 */
	public void rmAccion(Accion acc) {
		this.acciones.remove(acc);
	}
	
	@Override
	public String toString() {
		String str = "Operadores [acciones: {";
		for (int i = 0; i < acciones.size(); i++) {
			str += acciones.get(i).getNombre();
			if(i+1 < acciones.size()) {
				str += ",";
			}
		}
		str += "}]";
		return str;
	}
	
	/** GETTER Y SETTER **/
	public List<Accion> getAcciones() {
		return acciones;
	}
	public void setAcciones(List<Accion> acciones) {
		this.acciones = acciones;
	}
	/** **/
	
}
