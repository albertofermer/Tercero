package algorithms;

import java.util.HashSet;
import java.util.Set;

/**
 * @author Luis Javier
 * Clase para definir una acci�n
 */
public class Accion {
	
	String nombre;
	Set<String> precond = new HashSet<String>();
	Set<String> adicion = new HashSet<String>();
	Set<String> supresion = new HashSet<String>();
	
	/**
	 * Constructor
	 * @param nombre Nombre de la accion
	 * @param precond Precondiciones
	 * @param adicion Adiciones
	 * @param supresion Supresiones
	 */
	public Accion(String nombre, String precond, String adicion, String supresion) {
		this.nombre = nombre.trim();
		
		if(!precond.trim().replaceAll(" ", "").equals("")) {
			String[] strs = precond.trim().replaceAll(" ", "").split(",");
			for(String str: strs) this.precond.add(str);
		}
		
		if(!adicion.trim().replaceAll(" ", "").equals("")) {
			String[] strs = adicion.trim().replaceAll(" ", "").split(",");
			for(String str: strs) this.adicion.add(str);
		}
		
		if(!supresion.trim().replaceAll(" ", "").equals("")) {
			String[] strs = supresion.trim().replaceAll(" ", "").split(",");
			for(String str: strs) this.supresion.add(str);
		}
	}
	
	/**
	 * Verifica si esta acci�n es plausible.
	 * @param comprobacion String a comprobar
	 * @return True/false si/no plausible
	 */
	public boolean esPlausible(String comprobacion) {
		boolean cumple = false;
		for(String val1: comprobacion.split(",")) {
			if(!getAdicion().contains(val1)) {
				cumple = false;
				break;
			} else {
				cumple = true;
			}
		}
		return cumple;
	}
	
	/**
	 * Verifica si el estado actual cumple las precondiciones de la acci�n.
	 * @param e_Actual Estado actual
	 * @return True/false si/no verifica
	 */
	public boolean cumplePrecond(Estado e_Actual) {
		boolean cumple = false;
		for(String val: getPrecond()) {
			if(e_Actual.contains(val)) {
				cumple = true;
			} else {
				cumple = false;
				break;
			}
		}
		return cumple;
	}
	
	@Override
	public String toString() {
		return "Accion [nombre: '" + nombre + "', precond: {" + precond + "}, adicion: {" + adicion + "}, supresion: {" + supresion + "}]";
	}

	/** GETTER Y SETTER **/
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public Set<String> getPrecond() {
		return precond;
	}
	public void setPrecond(Set<String> precond) {
		this.precond = precond;
	}
	public Set<String> getAdicion() {
		return adicion;
	}
	public void setAdicion(Set<String> adicion) {
		this.adicion = adicion;
	}
	public Set<String> getSupresion() {
		return supresion;
	}
	public void setSupresion(Set<String> supresion) {
		this.supresion = supresion;
	}
	/** **/
}
