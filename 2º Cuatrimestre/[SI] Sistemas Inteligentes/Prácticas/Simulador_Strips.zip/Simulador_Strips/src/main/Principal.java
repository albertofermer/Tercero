package main;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;

import algorithms.A_Strips;
import algorithms.Accion;
import algorithms.Estado;
import algorithms.Operadores;
import algorithms.Plan;
import other.Par;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JCheckBox;
import javax.swing.JTextArea;
import javax.swing.border.LineBorder;
import java.awt.Color;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Arrays;
import java.util.List;

/**
 * @author Luis Javier
 * Clase principal y visual del programa
 */
@SuppressWarnings("serial")
public class Principal extends JFrame {

	private JPanel contentPane;
	private JTextField tf_E_Inicial;
	private JTextField tf_E_Objetivo;
	private JTextField tf_OP1_precond;
	private JTextField tf_OP2_precond;
	private JTextField tf_OP4_precond;
	private JTextField tf_OP3_precond;
	private JTextField tf_OP1_adicion;
	private JTextField tf_OP2_adicion;
	private JTextField tf_OP3_adicion;
	private JTextField tf_OP4_adicion;
	private JTextField tf_OP1_supresion;
	private JTextField tf_OP2_supresion;
	private JTextField tf_OP3_supresion;
	private JTextField tf_OP4_supresion;
	private JCheckBox chB_OP1;
	private JCheckBox chB_OP2;
	private JCheckBox chB_OP3;
	private JCheckBox chB_OP4;
	private JCheckBox chB_PrimeraSolucion;
	private JTextArea textArea;

	/**
	 * Lanza la aplicaci�n
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					System.out.println("[INICIO DE PROGRAMA]\n");
					Principal frame = new Principal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Constructor de la clase.
	 * Crea el frame principal con sus campos.
	 */
	public Principal() {
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				System.out.println("\n[FIN DE PROGRAMA]");
			}
		});
		Border border = BorderFactory.createLineBorder(Color.BLACK);
		setResizable(false);
		setTitle("SIMULADOR STRIPS");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 730, 474);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lbl_E_Inicial = new JLabel("ESTADO INICIAL");
		lbl_E_Inicial.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_E_Inicial.setFont(new Font("Arial", Font.BOLD, 12));
		lbl_E_Inicial.setBounds(10, 11, 127, 20);
		panel.add(lbl_E_Inicial);
		
		tf_E_Inicial = new JTextField();
		tf_E_Inicial.setHorizontalAlignment(SwingConstants.CENTER);
		tf_E_Inicial.setBounds(10, 34, 127, 20);
		panel.add(tf_E_Inicial);
		tf_E_Inicial.setColumns(10);
		
		JLabel lbl_E_Objetivo = new JLabel("ESTADO OBJETIVO");
		lbl_E_Objetivo.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_E_Objetivo.setFont(new Font("Arial", Font.BOLD, 12));
		lbl_E_Objetivo.setBounds(10, 65, 127, 20);
		panel.add(lbl_E_Objetivo);
		
		tf_E_Objetivo = new JTextField();
		tf_E_Objetivo.setHorizontalAlignment(SwingConstants.CENTER);
		tf_E_Objetivo.setColumns(10);
		tf_E_Objetivo.setBounds(10, 88, 127, 20);
		panel.add(tf_E_Objetivo);
		
		JLabel lbl_Operadores = new JLabel("OPERADORES\r\n");
		lbl_Operadores.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_Operadores.setFont(new Font("Arial", Font.BOLD, 12));
		lbl_Operadores.setBounds(165, 11, 107, 20);
		panel.add(lbl_Operadores);
		
		JLabel lbl_Precond = new JLabel("Precond");
		lbl_Precond.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_Precond.setFont(new Font("Arial", Font.BOLD, 12));
		lbl_Precond.setBounds(261, 16, 83, 20);
		panel.add(lbl_Precond);
		
		JLabel lbl_Adicion = new JLabel("Adicion");
		lbl_Adicion.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_Adicion.setFont(new Font("Arial", Font.BOLD, 12));
		lbl_Adicion.setBounds(354, 16, 83, 20);
		panel.add(lbl_Adicion);
		
		JLabel lbl_SupresionPrecond = new JLabel("Supresion");
		lbl_SupresionPrecond.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_SupresionPrecond.setFont(new Font("Arial", Font.BOLD, 12));
		lbl_SupresionPrecond.setBounds(447, 16, 83, 20);
		panel.add(lbl_SupresionPrecond);
		
		tf_OP1_precond = new JTextField();
		tf_OP1_precond.setHorizontalAlignment(SwingConstants.CENTER);
		tf_OP1_precond.setColumns(10);
		tf_OP1_precond.setBounds(257, 38, 87, 20);
		panel.add(tf_OP1_precond);
		
		tf_OP2_precond = new JTextField();
		tf_OP2_precond.setHorizontalAlignment(SwingConstants.CENTER);
		tf_OP2_precond.setColumns(10);
		tf_OP2_precond.setBounds(257, 65, 87, 20);
		panel.add(tf_OP2_precond);
		
		tf_OP4_precond = new JTextField();
		tf_OP4_precond.setEnabled(false);
		tf_OP4_precond.setHorizontalAlignment(SwingConstants.CENTER);
		tf_OP4_precond.setColumns(10);
		tf_OP4_precond.setBounds(257, 118, 87, 20);
		panel.add(tf_OP4_precond);
		
		tf_OP3_precond = new JTextField();
		tf_OP3_precond.setHorizontalAlignment(SwingConstants.CENTER);
		tf_OP3_precond.setColumns(10);
		tf_OP3_precond.setBounds(257, 91, 87, 20);
		panel.add(tf_OP3_precond);
		
		tf_OP1_adicion = new JTextField();
		tf_OP1_adicion.setHorizontalAlignment(SwingConstants.CENTER);
		tf_OP1_adicion.setColumns(10);
		tf_OP1_adicion.setBounds(354, 38, 87, 20);
		panel.add(tf_OP1_adicion);
		
		tf_OP2_adicion = new JTextField();
		tf_OP2_adicion.setHorizontalAlignment(SwingConstants.CENTER);
		tf_OP2_adicion.setColumns(10);
		tf_OP2_adicion.setBounds(354, 65, 87, 20);
		panel.add(tf_OP2_adicion);
		
		tf_OP3_adicion = new JTextField();
		tf_OP3_adicion.setHorizontalAlignment(SwingConstants.CENTER);
		tf_OP3_adicion.setColumns(10);
		tf_OP3_adicion.setBounds(354, 91, 87, 20);
		panel.add(tf_OP3_adicion);
		
		tf_OP4_adicion = new JTextField();
		tf_OP4_adicion.setEnabled(false);
		tf_OP4_adicion.setHorizontalAlignment(SwingConstants.CENTER);
		tf_OP4_adicion.setColumns(10);
		tf_OP4_adicion.setBounds(354, 118, 87, 20);
		panel.add(tf_OP4_adicion);
		
		tf_OP1_supresion = new JTextField();
		tf_OP1_supresion.setHorizontalAlignment(SwingConstants.CENTER);
		tf_OP1_supresion.setColumns(10);
		tf_OP1_supresion.setBounds(447, 38, 87, 20);
		panel.add(tf_OP1_supresion);
		
		tf_OP2_supresion = new JTextField();
		tf_OP2_supresion.setHorizontalAlignment(SwingConstants.CENTER);
		tf_OP2_supresion.setColumns(10);
		tf_OP2_supresion.setBounds(447, 65, 87, 20);
		panel.add(tf_OP2_supresion);
		
		tf_OP3_supresion = new JTextField();
		tf_OP3_supresion.setHorizontalAlignment(SwingConstants.CENTER);
		tf_OP3_supresion.setColumns(10);
		tf_OP3_supresion.setBounds(447, 91, 87, 20);
		panel.add(tf_OP3_supresion);
		
		tf_OP4_supresion = new JTextField();
		tf_OP4_supresion.setEnabled(false);
		tf_OP4_supresion.setHorizontalAlignment(SwingConstants.CENTER);
		tf_OP4_supresion.setColumns(10);
		tf_OP4_supresion.setBounds(447, 118, 87, 20);
		panel.add(tf_OP4_supresion);
		
		JLabel lbl_Precond_1 = new JLabel("<html>Mostrar <b>S\u00D3LO</b><br>primera soluci\u00F3n:</html>");
		lbl_Precond_1.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_Precond_1.setFont(new Font("Arial", Font.PLAIN, 12));
		lbl_Precond_1.setBounds(562, 29, 112, 45);
		panel.add(lbl_Precond_1);
		
		JPanel panel_inferior = new JPanel();
		panel_inferior.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_inferior.setBounds(0, 186, 704, 239);
		panel.add(panel_inferior);
		panel_inferior.setLayout(null);
		
		JLabel lbl_Simulacion = new JLabel("RESULTADO SIMULACI\u00D3N");
		lbl_Simulacion.setHorizontalAlignment(SwingConstants.LEFT);
		lbl_Simulacion.setFont(new Font("Arial", Font.BOLD, 12));
		lbl_Simulacion.setBounds(10, 11, 156, 20);
		panel_inferior.add(lbl_Simulacion);
		
		textArea = new JTextArea();
		textArea.setFont(new Font("Consolas", Font.BOLD, 14));
		textArea.setLineWrap(true);
		textArea.setWrapStyleWord(true);
		textArea.setEditable(false);
		textArea.setRows(6);
		textArea.setBounds(10, 42, 684, 186);
		textArea.setBorder(BorderFactory.createCompoundBorder(border,BorderFactory.createEmptyBorder(10, 10, 10, 10)));
		panel_inferior.add(textArea);
		
		chB_OP1 = new JCheckBox("OP1");
		chB_OP1.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				boolean checked = e.getStateChange() != 2;
				tf_OP1_precond.setEnabled(checked);
				tf_OP1_adicion.setEnabled(checked);
				tf_OP1_supresion.setEnabled(checked);
			}
		});
		chB_OP1.setBounds(201, 37, 50, 23);
		panel.add(chB_OP1);
		
		chB_OP2 = new JCheckBox("OP2");
		chB_OP2.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				boolean checked = e.getStateChange() != 2;
				tf_OP2_precond.setEnabled(checked);
				tf_OP2_adicion.setEnabled(checked);
				tf_OP2_supresion.setEnabled(checked);
			}
		});
		chB_OP2.setBounds(201, 63, 50, 23);
		panel.add(chB_OP2);
		
		chB_OP3 = new JCheckBox("OP3");
		chB_OP3.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				boolean checked = e.getStateChange() != 2;
				tf_OP3_precond.setEnabled(checked);
				tf_OP3_adicion.setEnabled(checked);
				tf_OP3_supresion.setEnabled(checked);
			}
		});
		chB_OP3.setBounds(201, 89, 50, 23);
		panel.add(chB_OP3);
		
		chB_OP4 = new JCheckBox("OP4");
		chB_OP4.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				boolean checked = e.getStateChange() != 2;
				tf_OP4_precond.setEnabled(checked);
				tf_OP4_adicion.setEnabled(checked);
				tf_OP4_supresion.setEnabled(checked);
			}
		});
		chB_OP4.setBounds(201, 115, 50, 23);
		panel.add(chB_OP4);

		chB_PrimeraSolucion = new JCheckBox("Mostrar primera");
		chB_PrimeraSolucion.setSelected(true);
		chB_PrimeraSolucion.setBounds(568, 80, 130, 23);
		panel.add(chB_PrimeraSolucion);
		

		JButton btn_LimpiarCampos = new JButton("LIMPIAR CAMPOS");
		btn_LimpiarCampos.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent e) {
				clearData();
			}
		});
		btn_LimpiarCampos.setBounds(10, 152, 147, 23);
		panel.add(btn_LimpiarCampos);
		
		JButton btn_RestablecerCampos = new JButton("RESTABLECER CAMPOS");
		btn_RestablecerCampos.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent e) {
				resetData();
			}
		});
		btn_RestablecerCampos.setBounds(181, 152, 173, 23);
		panel.add(btn_RestablecerCampos);
		
		JButton btn_SimularDatos = new JButton("SIMULAR DATOS");
		btn_SimularDatos.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent e) {
				try {
					runSimulation();
				} catch (CloneNotSupportedException e1) {
					e1.printStackTrace();
				}
			}
		});
		btn_SimularDatos.setBounds(547, 152, 147, 23);
		panel.add(btn_SimularDatos);
		
		resetData();
	}
	
	/**
	 * Limpia los datos de los campos del frame.
	 */
	public void clearData() {
		this.tf_E_Inicial.setText("");
		this.tf_E_Objetivo.setText("");
		this.tf_OP1_precond.setText("");
		this.tf_OP1_adicion.setText("");
		this.tf_OP1_supresion.setText("");
		this.tf_OP2_precond.setText("");
		this.tf_OP2_adicion.setText("");
		this.tf_OP2_supresion.setText("");
		this.tf_OP3_precond.setText("");
		this.tf_OP3_adicion.setText("");
		this.tf_OP3_supresion.setText("");
		this.tf_OP4_precond.setText("");
		this.tf_OP4_adicion.setText("");
		this.tf_OP4_supresion.setText("");
		this.chB_OP1.setSelected(false);
		this.chB_OP2.setSelected(false);
		this.chB_OP3.setSelected(false);
		this.chB_OP4.setSelected(false);
	}
	
	/**
	 * Restablece los datos por defecto en el frame.
	 */
	public void resetData() {
		this.tf_E_Inicial.setText("b, d, e");
		this.tf_E_Objetivo.setText("a, d");
		this.tf_OP1_precond.setText("b,d");
		this.tf_OP1_adicion.setText("c,e");
		this.tf_OP1_supresion.setText("d");
		this.tf_OP2_precond.setText("b");
		this.tf_OP2_adicion.setText("a");
		this.tf_OP2_supresion.setText("c,d");
		this.tf_OP3_precond.setText("a");
		this.tf_OP3_adicion.setText("d");
		this.tf_OP3_supresion.setText("");
		this.tf_OP4_precond.setText("");
		this.tf_OP4_adicion.setText("");
		this.tf_OP4_supresion.setText("");
		this.chB_OP1.setSelected(true);
		this.chB_OP2.setSelected(true);
		this.chB_OP3.setSelected(true);
		this.chB_OP4.setSelected(false);
	}
	
	/**
	 * Lanza una simulaci�n de STRIPS con los datos del frame.
	 * @throws CloneNotSupportedException
	 */
	public void runSimulation() throws CloneNotSupportedException {
		this.cls();
		
		// OTRAS VARIABLES
		// primeraFactible: Si es true, el programa mostrar� solo la primera soluci�n factible. False
		// para mostrar todas.
		boolean primeraFactible = this.chB_PrimeraSolucion.isSelected();

		// ESTADOS
		Estado e_Inicial = new Estado("Inicial", this.tf_E_Inicial.getText());
		Estado e_Objetivo = new Estado("Objetivo", this.tf_E_Objetivo.getText());

		// OPERADORES
		Accion OP1 = new Accion("OP1", this.tf_OP1_precond.getText(), this.tf_OP1_adicion.getText(), this.tf_OP1_supresion.getText());
		Accion OP2 = new Accion("OP2", this.tf_OP2_precond.getText(), this.tf_OP2_adicion.getText(), this.tf_OP2_supresion.getText());
		Accion OP3 = new Accion("OP3", this.tf_OP3_precond.getText(), this.tf_OP3_adicion.getText(), this.tf_OP3_supresion.getText());
		Accion OP4 = new Accion("OP3", this.tf_OP4_precond.getText(), this.tf_OP4_adicion.getText(), this.tf_OP4_supresion.getText());
		Operadores ops = new Operadores();
		if(this.chB_OP1.isSelected()) ops.addAccion(OP1);
		if(this.chB_OP2.isSelected()) ops.addAccion(OP2);
		if(this.chB_OP3.isSelected()) ops.addAccion(OP3);
		if(this.chB_OP4.isSelected()) ops.addAccion(OP4);
		
		this.writeLine("### SOLUCIONES ###\n");
		List<Par> li = A_Strips.Simular(e_Inicial, e_Objetivo, ops, primeraFactible);
		if (li.size() == 0) {
			this.writeLine("> NO SE ENCONTR� SOLUCI�N");
		} else {
			for(Par p: li) {
				this.writeLine("[PILA INICIAL]: "+Arrays.toString((String[])p.prop1)+" --> [SOLUCION]: "+(Plan)p.prop2);
			}
		}
		this.writeLine("\n### ###");

	}
	
	/**
	 * Escriber una l�nea con salto en la pseudoconsola.
	 * @param str Cadena de texto
	 */
	public void writeLine(String str) {
		System.out.println(str+"\n");
		this.textArea.append(str+"\n");
	}
	
	/**
	 * Escriber una l�nea sin salto en la pseudoconsola.
	 * @param str Cadena de texto
	 */
	public void write(String str) {
		this.textArea.append(str);
	}
	
	/**
	 * Limpia la pseudoconsola.
	 */
	public void cls() {
		this.textArea.setText(null);
	}
}
