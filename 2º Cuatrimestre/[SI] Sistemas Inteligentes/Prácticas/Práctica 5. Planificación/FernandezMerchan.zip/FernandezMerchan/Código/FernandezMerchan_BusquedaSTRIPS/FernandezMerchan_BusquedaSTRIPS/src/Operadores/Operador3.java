package Operadores;

import java.util.LinkedList;
import java.util.List;

import Meta.Conjuncion_Meta;
import Meta.Meta;

/**
 * ============================================================================
 * * * * * * * * * * * * * * * Clase Operador3 * * * * * * * * * * * * * * * * *
 * ============================================================================
 * <p>
 * Operador3 es una clase que extiende la clase abstracta Operador.
 * </p>
 * 
 * <p>
 * Lista de Precondiciones: {a}
 * </p>
 * <p>
 * Lista de Adici�n: {d}
 * </p>
 * <p>
 * Lista de Supresi�n: {}
 * </p>
 * <p>
 * 
 * </p>
 * 
 * 
 * @author Alberto Fern�ndez
 *
 */
public class Operador3 extends Operador {
	/**
	 * El constructor de la clase se encarga de rellenar las listas de
	 * precondiciones, adici�n y supresi�n del operador.
	 */
	public Operador3() {
		List<Meta> pre = new LinkedList<>();
		pre.add(new Meta('a'));
		
		precondiciones.add(new Conjuncion_Meta(pre));
		adicion.add(new Meta('d'));

	}

	@Override
	public String toString() {

		return "op3";
	}
}
