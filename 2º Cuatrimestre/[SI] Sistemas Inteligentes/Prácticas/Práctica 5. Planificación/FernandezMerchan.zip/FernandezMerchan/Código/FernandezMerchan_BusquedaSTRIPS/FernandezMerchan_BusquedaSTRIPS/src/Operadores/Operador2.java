package Operadores;

import java.util.LinkedList;
import java.util.List;

import Meta.Conjuncion_Meta;
import Meta.Meta;

/**
 * ============================================================================
 * * * * * * * * * * * * * * * Clase Operador2 * * * * * * * * * * * * * * * * *
 * ============================================================================
 * <p>
 * Operador2 es una clase que extiende la clase abstracta Operador.
 * </p>
 * 
 * <p>
 * Lista de Precondiciones: {b}
 * </p>
 * <p>
 * Lista de Adici�n: {a}
 * </p>
 * <p>
 * Lista de Supresi�n: {c,d}
 * </p>
 * <p>
 * 
 * </p>
 * 
 * 
 * @author Alberto Fern�ndez
 *
 */
public class Operador2 extends Operador {

	/**
	 * El constructor de la clase se encarga de rellenar las listas de
	 * precondiciones, adici�n y supresi�n del operador.
	 */
	public Operador2() {
		
		List<Meta> pre = new LinkedList<>();
		pre.add(new Meta('b'));
		
		precondiciones.add(new Conjuncion_Meta(pre));
		
		adicion.add(new Meta('a'));

		supresion.add(new Meta('c'));
		supresion.add(new Meta('d'));
	}

	@Override
	public String toString() {

		return "op2";
	}

}
