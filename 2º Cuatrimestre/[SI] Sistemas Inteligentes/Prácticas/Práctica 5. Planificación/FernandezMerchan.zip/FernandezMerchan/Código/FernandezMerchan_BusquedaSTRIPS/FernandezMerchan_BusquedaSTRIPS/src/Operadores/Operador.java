package Operadores;

import java.util.LinkedList;
import java.util.List;

import Interfaces.Apilable;
import Meta.Conjuncion_Meta;
import Meta.Meta;
import STRIPS.Estado;

/**
 * ============================================================================
 * * * * * * * * * * * * * * * Clase Operador * * * * * * * * * * * * * * * * *
 * ============================================================================
 * <p>
 * Operador es una clase abstracta que se utiliza como base para crear los
 * operadores del problema.
 * </p>
 * 
 * <p>
 * Est� compuesta, principalmente, por tres listas que contendr�n las
 * precondiciones, las metas a�adidas tras ejecutar el operador y, por �ltimo,
 * las metas eliminadas tras ejecutarlo.
 * </p>
 * 
 * <p>
 * Implementa la interfaz Apilable porque es un objeto que ir� incluido en la
 * pila de objetivos. Es por ello que debe implementar el m�todo seCumple(Estado
 * e).
 * </p>
 * 
 * <p>
 * El c�digo que se le ha dado para detectarlo en la pila de objetivos es el 1.
 * </p>
 * 
 * 
 * 
 * @author Alberto Fern�ndez
 *
 */
public abstract class Operador implements Apilable {

	protected List<Conjuncion_Meta> precondiciones = new LinkedList<>();
	protected List<Meta> adicion = new LinkedList<>();
	protected List<Meta> supresion = new LinkedList<>();

	/**
	 * <p>
	 * Obtiene la lista de precondiciones del operador.
	 * </p>
	 * <p>
	 * Lista de Precondiciones: Lista de objetivos necesarios para poder aplicar el
	 * operador
	 * </p>
	 * 
	 * @return Lista de Precondiciones.
	 */
	public List<Conjuncion_Meta> getPrecondiciones() {
		return precondiciones;
	}

	/**
	 * <p>
	 * Obtiene la lista de adici�n del operador.
	 * </p>
	 * <p>
	 * Lista de Supresi�n: Lista de objetivos que se a�adir�n a la lista de
	 * objetivos del estado actual.
	 * </p>
	 * 
	 * @return Lista de Adici�n.
	 */
	public List<Meta> getAdicion() {
		return adicion;
	}

	/**
	 * <p>
	 * Obtiene la lista de supresi�n del operador.
	 * </p>
	 * <p>
	 * Lista de Supresi�n: Lista de objetivos que se eliminar�n de la lista de
	 * objetivos del estado actual.
	 * </p>
	 * 
	 * @return Lista de Supresion.
	 */
	public List<Meta> getSupresion() {
		return supresion;
	}

	/**
	 * Devuelve '1' como identificador del tipo de objeto Apilable.
	 */
	@Override
	public int getTipo() {
		return 1;
	}

	/**
	 * 
	 * Devuelve cierto si todas las precondiciones del operador se encuentran en la
	 * lista de objetivos cumplidos del Estado actual.
	 * 
	 */
	@Override
	public boolean seCumple(Estado e) {
		List<Meta> precond = new LinkedList<>();
		for(Conjuncion_Meta m : precondiciones) {
			
			precond.addAll(m.getObjetivos());
		}
		return e.getObjetivos().containsAll(precond);
	}

}
