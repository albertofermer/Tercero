package STRIPS;

import java.util.LinkedList;
import java.util.List;

import Interfaces.Apilable;
import Meta.Meta;
import Operadores.Operador;

public class Estado implements Cloneable{

	// Lista de objetivos que se cumplen en un momento determinado.
	private List<Meta> objetivos = new LinkedList<>();

	public Estado(List<Meta> obj) {
		objetivos.addAll(obj);
	}

	public List<Meta> getObjetivos() {
		return objetivos;
	}

	@Override
	public Object clone() {

		Estado nuevoEstado = new Estado(objetivos);

		return nuevoEstado;

	}

	public Estado aplicarOperador(Operador peek) {

		Estado e = (Estado) this.clone();
		// A�adir los objetivos que aparezcan en la lista de precondiciones
		e.getObjetivos().addAll(peek.getAdicion());
		// Eliminar los objetivos que aparezcan en la lista de supresion
		e.getObjetivos().removeAll(peek.getSupresion());

	
		return e;
	}
	

}
