package Operadores;

import java.util.LinkedList;
import java.util.List;

import Meta.Conjuncion_Meta;
import Meta.Meta;

/**
 * ============================================================================
 * * * * * * * * * * * * * * * Clase Operador1 * * * * * * * * * * * * * * * * *
 * ============================================================================
 * <p>
 * Operador1 es una clase que extiende la clase abstracta Operador.
 * </p>
 * 
 * <p>
 * Lista de Precondiciones: {b, d}
 * </p>
 * <p>
 * Lista de Adici�n: {c, e}
 * </p>
 * <p>
 * Lista de Supresi�n: {d}
 * </p>
 * <p>
 * 
 * </p>
 * 
 * 
 * @author Alberto Fern�ndez
 *
 */
public class Operador1 extends Operador {

	/**
	 * El constructor de la clase se encarga de
	 * rellenar las listas de precondiciones, adici�n
	 * y supresi�n del operador.
	 */
	public Operador1() {
		List<Meta> pre = new LinkedList<>();
		
		pre.add(new Meta('b'));
		pre.add(new Meta('d'));

		
		precondiciones.add(new Conjuncion_Meta(pre));
		
		adicion.add(new Meta('c'));
		adicion.add(new Meta('e'));

		supresion.add(new Meta('d'));

	}

	@Override
	public String toString() {

		return "op1";
	}

}
