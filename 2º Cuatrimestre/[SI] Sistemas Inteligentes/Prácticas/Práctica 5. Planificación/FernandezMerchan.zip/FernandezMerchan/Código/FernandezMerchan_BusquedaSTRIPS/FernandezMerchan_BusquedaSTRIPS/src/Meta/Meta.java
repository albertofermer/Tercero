package Meta;

import Interfaces.Apilable;
import STRIPS.Estado;

/**
 * ============================================================================
 * * * * * * * * * * * * * * * Clase Meta * * * * * * * * * * * * * * * * *
 * ============================================================================
 * <p>
 * Meta es una clase que representa cada objetivo de la lista de objetivos del
 * problema. Se utiliza en las listas de los operadores, en la pila de objetivos
 * y en la lista de objetivos del estado.
 * </p>
 * 
 * <p>
 * Est� compuesta por un atributo de tipo caracter que representar� el nombre de
 * la meta.
 * </p>
 * 
 * <p>
 * Implementa la interfaz Apilable porque es un objeto que ir� incluido en la
 * pila de objetivos. Es por ello que debe implementar el m�todo seCumple(Estado
 * e).
 * </p>
 * 
 * <p>
 * El c�digo que se le ha dado para detectarlo en la pila de objetivos es el 2.
 * </p>
 * 
 * 
 * 
 * @author Alberto Fern�ndez
 *
 */
public class Meta implements Apilable {
	private char objetivo;

	/**
	 * El constructor de la clase asigna el caracter obj al atributo objetivo.
	 * 
	 * @param obj
	 */
	public Meta(char obj) {
		objetivo = obj;
	}

	/**
	 * M�todo getter para obtener el caracter del objetivo.
	 * 
	 * @return
	 */
	public char getObjetivo() {
		return objetivo;
	}

	/**
	 * Obtiene el '2' como identificador del tipo de objeto Apilable.
	 * 
	 * @return 2
	 */
	@Override
	public int getTipo() {
		return 2;
	}

	/**
	 * 
	 * Devuelve cierto si la lista de objetivos del Estado e contiene la Meta.
	 * 
	 */
	@Override
	public boolean seCumple(Estado e) {

		return e.getObjetivos().contains(this);
	}

	/**
	 * Un objeto Meta ser� igual a otro si tienen el mismo caracter como
	 * representante del objetivo.
	 */
	@Override
	public boolean equals(Object o) {
		return ((Meta) o).getObjetivo() == this.getObjetivo();

	}

	@Override
	public String toString() {
		return Character.toString(objetivo);

	}
}
