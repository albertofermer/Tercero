package STRIPS;

import java.util.LinkedList;
import java.util.List;
import java.util.Stack;

import Interfaces.Apilable;
import Meta.*;
import Operadores.*;

/**
 * 
 * @author Alberto Fern�ndez
 *
 */
public class STRIPS {

	private static final int OPERADOR = 1;
	private static final int META = 2;
	private static final int CONJUNCION_METAS = 3;
	private List<Operador> plan;
	private List<Apilable> objetivos = new LinkedList<>();
	private Stack<Apilable> pilaObjetivos = new Stack<>();

	private Estado inicial;
	private Estado actual;

	private List<Operador> acciones = new LinkedList<>();

	public STRIPS(List<Meta> estadoFinal, List<Meta> estadoInicial) {

		objetivos.add(new Conjuncion_Meta(estadoFinal));

		pilaObjetivos.addAll(objetivos);

		/**
		 * * * * * * * Creacion de los Operadores. * * * *
		 *
		 * 
		 * Se insertan en una lista de posibles acciones todos los operadores que se
		 * pueden utilizar en el problema.
		 * 
		 * Para crear nuevos operadores se tendra que crear una nueva clase que extienda
		 * de la interfaz Operador y construya las listas de precondiciones, adicion y
		 * supresion.
		 * 
		 * 
		 */

		acciones.add(new Operador1());
		acciones.add(new Operador2());
		acciones.add(new Operador3());


		inicial = new Estado(estadoInicial);

		// El estado actual, al comienzo, ser� el estado inicial
		actual = (Estado) inicial.clone();

		/**
		 * * * * * * * Aplicamos el Algoritmo STRIPS. * * * *
		 *
		 * A continuaci�n aplicamos el algoritmo STRIPS implementado de manera
		 * recursiva. Para ello le pasaremos por par�metro el estado inicial, la pila de
		 * objetivos a cumplir y la lista de acciones posibles.
		 * 
		 * 
		 */

		plan = new LinkedList<>();
		System.out.println("-----------------> STRIPS <-----------------");
		plan = aplicarStripsRecursivo(inicial, pilaObjetivos, acciones);

		/**
		 * * * * * * * Anomal�a de Sussman. * * * *
		 *
		 * 
		 * Tenemos que comprobar que al plan no le afecte la anomal�a de Sussmann. Para
		 * ello, una vez acabe el algoritmo, aplicaremos las acciones al Estado Inicial
		 * y comprobaremos si el Estado Final contiene todos los objetivos.
		 * 
		 * 
		 */

		if (plan != null && seCumpleSussmann(plan, inicial)) {

			System.out.println("Se ha cumplido la anomal�a de Sussman.");
			plan = null; // Como el plan es incorrecto, devolvemos nulo.

		}

		System.out.println("PLAN: " + plan); // Si el plan no es nulo, escribimos la secuencia de acciones.

	}

	private boolean seCumpleSussmann(List<Operador> plan2, Estado inicial2) {

		Estado estadoSussmann = inicial2;
		List<Apilable> objet = new LinkedList<>();
		for (Operador o : plan2) {

			estadoSussmann = estadoSussmann.aplicarOperador(o);

		}

		for (Apilable a : objetivos) {

			if (a.getTipo() == CONJUNCION_METAS) {
				objet.addAll(((Conjuncion_Meta) a).getObjetivos());
			} else {
				objet.add(((Meta) a));
			}

		}

		return !estadoSussmann.getObjetivos().containsAll(objet);
	}

	@SuppressWarnings("unchecked")
	private List<Operador> aplicarStripsRecursivo(Estado actual, Stack<Apilable> pilaObjetivos,
			List<Operador> acciones) {

		if (pilaObjetivos.isEmpty())

			return new LinkedList<Operador>(); // Si la pila est� vac�a devuelve un plan vac�o.
		else {

			System.out.println("Cima pila: " + pilaObjetivos.peek());
			System.out.println("Pila: " + pilaObjetivos);
			System.out.println("Estado_Actual: " + actual.getObjetivos());
			System.out.println("-------------------------------------------");

			Apilable cima = pilaObjetivos.peek();

			switch (cima.getTipo()) {

			case OPERADOR: // Si la cima es una acci�n,

				Operador op = (Operador) pilaObjetivos.peek();
				if (hayCiclo(op, pilaObjetivos, actual))
					return null;
				else if (op.seCumple(actual)) { // Si se puede aplicar el operador al estado actual
					// Se ejecuta el operador
					pilaObjetivos.pop();
					Estado Eactual = actual.aplicarOperador(op);
					// Y se aplica Strips para el resto del problema.
					List<Operador> siguiente = aplicarStripsRecursivo(Eactual, pilaObjetivos, acciones);
					if (siguiente != null) { // Si ha finalizado el problema sin errores,
						// Se crea un nuevo plan
						List<Operador> nuevoPlan = new LinkedList<>();
						// Se a�ade el operador que hemos analizado
						nuevoPlan.add(op);
						// Se a�ade el resto del plan.
						nuevoPlan.addAll(siguiente);
						return nuevoPlan;
					}
					// En caso de que haya fallado algo, devolvemos nulo.
					return null;

				} else { // Si el operador no se puede aplicar
							// Se a�aden sus precondiciones a la pila.

					for (Apilable a : op.getPrecondiciones()) {
						pilaObjetivos.push(a);
					}

					List<Operador> siguiente = aplicarStripsRecursivo(actual, pilaObjetivos, acciones);
					return siguiente;

				}
			case META: // Si la cima de la pila es una meta
				if (cima.seCumple(actual)) { // Si se cumple el objetivo que hay en la cima de la pila

					// Se extrae de la pila
					pilaObjetivos.pop();
					// Resolvemos el resto del problema.
					return aplicarStripsRecursivo(actual, pilaObjetivos, acciones);

				} else { // Si no se cumple el objetivo

					// Buscar un operador que a�ada los objetivos necesarios para que se cumpla.
					List<Operador> ops = BuscarAccion(acciones, (Meta) pilaObjetivos.peek());
					if (!ops.isEmpty()) { // Si encuentra una acci�n, se apilan sus precondiciones en la pila.
						for (Operador o : ops) {

							Stack<Apilable> pCopia = (Stack<Apilable>) pilaObjetivos.clone();
							Estado actualCopia = (Estado) actual.clone();
							pCopia.push(o);
							List<Operador> siguiente = aplicarStripsRecursivo(actualCopia, (Stack<Apilable>) pCopia,
									acciones);
							if (siguiente != null)
								return siguiente;

						}

					}
					return null;

				}
			case CONJUNCION_METAS:

				if (cima.seCumple(actual)) {
					// Se extrae de la pila
					pilaObjetivos.pop();
					// Resolvemos el resto del problema.
					return aplicarStripsRecursivo(actual, pilaObjetivos, acciones);
				} else {

					// generar combinaciones de la conjuncion de metas:
					List<Conjuncion_Meta> combinaciones_cm = generarPermutaciones(
							(Conjuncion_Meta) pilaObjetivos.peek());
					System.out.println("Combinaciones: " + combinaciones_cm);
					// pilaObjetivos.pop();
					for (Conjuncion_Meta cm : combinaciones_cm) {

						Stack<Apilable> pCopia = (Stack<Apilable>) pilaObjetivos.clone();

						for (Meta m : cm.getObjetivos())
							pCopia.push(m);

						Estado actualCopia = (Estado) actual.clone();
						List<Operador> siguiente = aplicarStripsRecursivo(actualCopia, (Stack<Apilable>) pCopia,
								acciones);

						if (siguiente != null)
							return siguiente;
					}

				}
				return null;

			default:
				throw new IllegalArgumentException("Unexpected value: " + pilaObjetivos.peek().getTipo());
			}

		}

	}

	private List<Conjuncion_Meta> generarPermutaciones(Conjuncion_Meta peek) {

		List<Conjuncion_Meta> cm = new LinkedList<>();

		List<Meta> elementos = peek.getObjetivos();
		int n = elementos.size(); // Tipos para escoger
		int r = elementos.size(); // Elementos elegidos
		generarPermutacionesRec(elementos, "", n, r, cm);

		return cm;
	}

	private static void generarPermutacionesRec(List<Meta> elem, String act, int n, int r, List<Conjuncion_Meta> cm) {
		if (n == 0) {
			List<Meta> cmC = new LinkedList<>();
			String[] cmS = act.split(",");
			for (String s : cmS) {
				s = s.trim();
				if (s.length() > 0)
					cmC.add(new Meta(s.charAt(0)));
			}
			cm.add(new Conjuncion_Meta(cmC));
			// System.out.println(cmC);

		} else {
			for (int i = 0; i < r; i++) {
				if (!act.contains(elem.get(i).toString())) { // Controla que no haya repeticiones
					generarPermutacionesRec(elem, act + elem.get(i) + ", ", n - 1, r, cm);

				}
			}
		}

	}

	private boolean hayCiclo(Operador op, Stack<Apilable> pilaObjetivos, Estado actual) {
		// Hay ciclo si en la pila se a�ade una accion que ya estaba anteriormente

		if (!op.seCumple(actual) && pilaObjetivos.contains(op)) {
			System.out.println("Hay ciclo");
			// System.out.println(pilaObjetivos);
			return true;
		}

		// System.out.println("No Ciclo");
		return false;
	}

	private List<Operador> BuscarAccion(List<Operador> accionesPosibles, Meta peek) {

		List<Operador> tmp = new LinkedList<>();
		for (Operador o : accionesPosibles) {
			// Si el operador a�ade el objetivo peek Y se cumplen sus precondiciones, se
			// a�ade a la lista de posibles acciones
//			System.out.println(o.getAdicion());
//			System.out.println("Cima:"  + peek);
//			System.out.println(o.getAdicion().contains(peek));
			if (o.getAdicion().contains(peek)) {

				tmp.add(o);

			}

		}
		return tmp;
	}

}
