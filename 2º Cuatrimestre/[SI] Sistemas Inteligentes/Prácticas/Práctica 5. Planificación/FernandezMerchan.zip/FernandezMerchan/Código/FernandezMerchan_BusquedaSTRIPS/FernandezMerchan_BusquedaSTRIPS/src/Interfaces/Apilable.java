package Interfaces;

import STRIPS.Estado;

/**
 * ============================================================================
 * * * * * * * * * * * * * * * Clase Apilable * * * * * * * * * * * * * * * * *
 * ============================================================================
 * <p>
 * Apilable es una interfaz que se usar� para recoger todos los objetos que
 * pueden ser apilados en la pila de objetivos del algoritmo STRIPS.
 * </p>
 * 
 * 
 * @author Alberto Fern�ndez
 *
 */
public interface Apilable {
	public int getTipo();

	public boolean seCumple(Estado e);
}
