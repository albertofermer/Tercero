package Meta;

import java.util.ArrayList;
import java.util.List;

import Interfaces.Apilable;
import STRIPS.Estado;

/**
 * ============================================================================
 * * * * * * * * * * * * * * * Clase Conjuncion_Meta * * * * * * * * * * * * * *
 * * * *
 * ============================================================================
 * <p>
 * Conjuncion_Meta es una clase que representa una lista de objetivos. Una
 * conjunci�n de metas ser� cierta si se cumplen todas las metas que la forman.
 * </p>
 * 
 * <p>
 * Est� compuesta por un atributo de tipo caracter que representar� el nombre de
 * la meta.
 * </p>
 * 
 * <p>
 * Implementa la interfaz Apilable porque es un objeto que ir� incluido en la
 * pila de objetivos. Es por ello que debe implementar el m�todo seCumple(Estado
 * e).
 * </p>
 * 
 * <p>
 * El c�digo que se le ha dado para detectarlo en la pila de objetivos es el 3.
 * </p>
 * 
 * 
 * 
 * @author Alberto Fern�ndez
 *
 */
public class Conjuncion_Meta implements Apilable {
	private List<Meta> objetivo = new ArrayList<>();

	/**
	 * El constructor de la clase asigna el caracter obj al atributo objetivo.
	 * 
	 * @param obj
	 */
	public Conjuncion_Meta(List<Meta> obj) {
		
		objetivo = obj;
	}
	
	public Conjuncion_Meta(Meta m) {
		List<Meta> meta = new ArrayList<>();
		meta.add(m);
		objetivo = meta;
	}

	/**
	 * M�todo getter para obtener la lista de objetivos.
	 * 
	 * @return
	 */
	public List<Meta> getObjetivos() {
		return objetivo;
	}

	/**
	 * Obtiene el '3' como identificador del tipo de objeto Apilable.
	 * 
	 * @return 3
	 */
	@Override
	public int getTipo() {
		return 3;
	}

	/**
	 * 
	 * Devuelve cierto si todos los elementos de la lista de metas aparecen en
	 * los objetivos del Estado e.
	 * 
	 */
	@Override
	public boolean seCumple(Estado e) {
		
		
		for (Meta m : objetivo) {
			
			if(!e.getObjetivos().contains(m)) {
				return false;
			}
		}
		
		
		return true;
	}

	/**
	 * Un objeto Conjuncion_Meta ser� igual a otro si su lista de objetivos tienen
	 * los mismos objetivos.
	 */
	@Override
	public boolean equals(Object o) {
		
		return ((Conjuncion_Meta) o).getObjetivos().containsAll(objetivo);
	}

	@Override
	public String toString() {
		return objetivo.toString();

	}
}
