package Principal;

import java.util.LinkedList;
import java.util.List;

import Meta.Meta;
import STRIPS.STRIPS;

public class Principal {

	public static void main(String[] args) {

		/**
		 * * * * * * * Insercion en la Pila de Objetivos. * * * *
		 *
		 * 
		 * Para insertar en la pila de objetivos deber� descomentar la l�nea
		 * que corresponda con el objetivo que quiere cumplir.
		 * 
		 * Al ser una conjunci�n de metas, se intentar�n todas las posibles
		 * permutaciones hasta que se encuentren todos los objetivos en
		 * el estado actual o no haya soluci�n.
		 * 
		 */

		List<Meta> listaObjetivosFinales = new LinkedList<>();
		listaObjetivosFinales.add(new Meta('a'));
//		listaObjetivosFinales.add(new Meta('b'));
//		listaObjetivosFinales.add(new Meta('c'));
		listaObjetivosFinales.add(new Meta('d'));
//		listaObjetivosFinales.add(new Meta('e'));

		/**
		 * * * * * * * Creacion del Estado Inicial. * * * *
		 *
		 * Para crear el estado inicial es necesaria una lista de objetivos que se
		 * cumplen en dicho estado. Para modificar esa lista tan solo descomenta o
		 * comenta los objetivos que se cumplan en dicho estado inicial. 
		 * 
		 */
		List<Meta> listaObjetivosIniciales = new LinkedList<>();
//		listaObjetivosIniciales.add(new Meta('a'));
		listaObjetivosIniciales.add(new Meta('b'));
//		listaObjetivosIniciales.add(new Meta('c'));
		listaObjetivosIniciales.add(new Meta('d'));
		listaObjetivosIniciales.add(new Meta('e'));

		STRIPS s = new STRIPS(listaObjetivosFinales, listaObjetivosIniciales);

	}
}
